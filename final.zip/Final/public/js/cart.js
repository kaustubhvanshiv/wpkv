const cart =[];
const addToCart =(item) => {
    const existingItem = cart.find(cartItem => cartItem.id === item.id);
    if(existingItem){
        existingItem.quantity += item.quantity;
    }else
    {
        cart.push(item);
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Added to Cart!');
    UpdateOrderSummery();
};

const loadCart = () =>{
    const storedCart = localStorage.getItem('cart');
    if(storedCart){
        cart.push(...JSON.parse(storedCart));
    }
};


const displayCartItems = () => {
    const cartContainer = document.querySelector('.cart-grid');
    cartContainer.innerHTML = '';
    cart.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');
        cartItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}" class="cart-img">
            <div class="cart-item-details">
                <h3 class="cart-item-title">${item.name}</h3>
                <p class="cart-item-price">₹${item.price}</p>
                <div class="quantity-container">
                    <button class="quantity-btn" onclick="updateQuantity('${item.id}', -1)">-</button>
                    <input type="number" class="quantity-input" value="${item.quantity}" min="1" readonly>
                    <button class="quantity-btn" onclick="updateQuantity('${item.id}', 1)">+</button>
                </div>
                <button class="remove-item" onclick="removeFromCart('${item.id}')">Remove</button>
            </div>
        `;
        cartContainer.appendChild(cartItem);
    });
    updateOrderSummary();
};

const updateQuantity = (id, change) => {
    const item = cart.find(cartItem => cartItem.id === id);
    if (item) {
        item.quantity += change;
        if (item.quantity <= 0) {
            removeFromCart(id);
        } else {
            localStorage.setItem('cart', JSON.stringify(cart));
            displayCartItems();
        }
    }
};

const removeFromCart = (id) => {
    const itemIndex = cart.findIndex(cartItem => cartItem.id === id);
    if (itemIndex > -1) {
        cart.splice(itemIndex, 1);
        localStorage.setItem('cart', JSON.stringify(cart));
        displayCartItems();
    }
};

const updateOrderSummary = () => {
    const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const tax = subtotal * 0.1; 
    const total = subtotal + tax;

    document.getElementById('subtotal').textContent = subtotal.toFixed(2);
    document.getElementById('tax').textContent = tax.toFixed(2);
    document.getElementById('total').textContent = total.toFixed(2);
};

window.addEventListener('load', () => {
    loadCart();
    if (document.querySelector('.cart-grid')) {
        displayCartItems();
    }
    document.querySelector('.checkout-btn').addEventListener('click', function() {
        window.location.href = 'payment.html';
    });
});
