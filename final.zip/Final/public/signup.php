<?php
$servername = "localhost";
$username = "root";
$password_db = "";
$dbname = "log_in";

$conn = new mysqli($servername, $username, $password_db, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];

    if ($password !== $confirm_password) {
        echo "Passwords do not match.";
        exit();
    }


    $sql = "SELECT * FROM users WHERE username = '$username' OR email = '$email'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "Username or email already exists.";
        exit();
    }

    $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$confirm_password')";
    if ($conn->query($sql) === TRUE) {
         header("Location: index2.html");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
$conn->close();
?>
