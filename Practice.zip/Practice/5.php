<?php
if($_SERVER["REQUEST_METHOD"]=='GET'){
    $number=$_F
}

?>