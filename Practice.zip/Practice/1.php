<?php
if($_SERVER['REQUEST_METHOD']== 'GET'){
    $marks=$_GET['percentage'];

    if ($marks >= 60){
        echo "First Division";
    }elseif($marks>=45 && $marks <=59){
        echo "Second Division";
    }elseif($marks>=33 && $marks <=44){
        echo "Third Division";
    }elseif($marks < 33) {
        echo "Fail";
    }
}


?>