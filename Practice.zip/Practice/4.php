<?php
if($_SERVER["REQUEST_METHOD"]=='GET'){
    $units= $_GET['units'];
    if($units<=50){
        $bills=$units*3.50;
    }
    elseif($units<=150){
        $bills=(50 * 3.50)+(($units-50) *4 );
    }elseif ($units<=250) {
        $bills=(50 * 3.50)+(100 * 4)+(($units-150) * 5.20);
    }elseif ($units>250) {
        $bills=(50 * 3.50)+(100 * 4)+(100 * 5.20)+(($units-250)*6.50);
    }
    echo "Bill For $units is:".$bills;
}
?>