<?php
if($_SERVER["REQUEST_METHOD"]=='GET'){
    $number=$_GET['factorial'];
    
    function factorial($n){
        if($n <= 1){
            return 1;
        }else
        {
            return $n * factorial($n - 1);
        }
    }
    if($number>=0){
        echo "Factorail of $number is: ". factorial($number);
    }else{
       echo "Please enter a non-negative integer.";
    }

}
?>
